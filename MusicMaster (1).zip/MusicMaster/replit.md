# Discord Music Bot

## Overview

This is a Discord music bot built with Python that can join voice channels and play music from various sources, primarily YouTube. The bot provides a queue-based music playback system with configurable settings and command-based interaction.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The bot follows a modular architecture with separation of concerns:

- **Main Entry Point**: `main.py` handles bot initialization and error handling
- **Bot Core**: `music_bot.py` contains the main Discord bot class and command handling
- **Queue Management**: `music_queue.py` manages music queues for each Discord server
- **Configuration**: `config.py` centralizes all bot settings and environment variable handling
- **Utilities**: `utils.py` provides helper functions for common operations

The architecture uses an asynchronous, event-driven approach suitable for Discord's real-time nature.

## Key Components

### MusicBot Class
- Extends `discord.ext.commands.Bot`
- Manages voice clients and music queues per Discord server
- Handles Discord intents for message content and voice states
- Integrates with yt-dlp for audio extraction

### MusicQueue Class
- Queue-based system using Python's `deque` for efficient operations
- Maintains current song, queue, and history (last 10 songs)
- Thread-safe operations for concurrent access

### Configuration System
- Environment variable-based configuration
- Comprehensive settings for timeouts, quality, features, and rate limiting
- Default values provided for all settings

### Audio Processing
- Uses yt-dlp (YouTube-DL fork) for audio extraction
- Configurable audio quality settings
- Support for various audio sources beyond YouTube

## Data Flow

1. **Command Reception**: User sends command with music request
2. **URL Processing**: Bot determines if input is URL or search term
3. **Audio Extraction**: yt-dlp extracts audio information and stream URL
4. **Queue Management**: Song added to server-specific queue
5. **Playback**: Bot joins voice channel and plays audio
6. **State Management**: Queue updates and history tracking

## External Dependencies

### Core Dependencies
- **discord.py**: Discord API interaction and bot framework
- **yt-dlp**: Audio extraction from various sources (YouTube, SoundCloud, etc.)

### Runtime Dependencies
- **asyncio**: Asynchronous operation handling
- **logging**: Comprehensive logging system
- **collections.deque**: Efficient queue operations

### Environment Variables
- `DISCORD_BOT_TOKEN`: Required Discord bot authentication token
- Various optional configuration variables for customization

## Deployment Strategy

### Environment Setup
- Requires Python 3.7+ with asyncio support
- Environment variables for configuration
- File logging to `bot.log` with console output

### Scalability Considerations
- Per-server queue isolation prevents cross-server interference
- Rate limiting implemented for both per-user and global limits
- Configurable timeouts prevent resource leaks

### Error Handling
- Comprehensive logging at multiple levels
- Graceful shutdown handling for KeyboardInterrupt
- Exception propagation for debugging

### Security Features
- Token-based authentication via environment variables
- Rate limiting to prevent abuse
- Optional same-channel requirement for music commands
- Configurable content restrictions (playlists, live streams)

## Recent Changes

### July 11, 2025 - Playlist System Implementation
- **Added comprehensive playlist management system** with persistent storage
- **Created playlist_manager.py** for all playlist operations (create, delete, add/remove songs, etc.)
- **Implemented 9 new playlist commands** with aliases for easy use
- **Added JSON-based storage** for playlists with per-server isolation
- **Enhanced help system** to include playlist commands with organized sections
- **Volume increased to 200%** for maximum audio output
- **Multi-platform audio support** working with SoundCloud fallback when YouTube blocked

The bot is designed to be easily deployable on various platforms with minimal configuration, while providing extensive customization options for different use cases.