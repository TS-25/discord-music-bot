# Discord Music Bot Dependencies

## Python Packages (install via pip)

```bash
pip install discord.py>=2.5.0
pip install yt-dlp>=2025.6.30
pip install PyNaCl>=1.5.0
pip install aiohttp>=3.8.0
pip install cffi>=1.15.0
pip install pycparser>=2.21
pip install opuslib>=3.0.0
```

## Or install all at once:
```bash
pip install discord.py yt-dlp PyNaCl aiohttp cffi pycparser opuslib
```

## System Dependencies

### Ubuntu/Debian:
```bash
sudo apt update
sudo apt install ffmpeg libopus0 libffi-dev python3-dev
```

### CentOS/RHEL/Fedora:
```bash
sudo yum install ffmpeg opus libffi-devel python3-devel
# or for newer versions:
sudo dnf install ffmpeg opus libffi-devel python3-devel
```

### macOS:
```bash
brew install ffmpeg opus libffi
```

### Windows:
1. Download FFmpeg from https://ffmpeg.org/download.html
2. Extract and add to system PATH
3. Install Python packages as above

## Environment Variables Required

- `DISCORD_BOT_TOKEN` - Your Discord bot token from Discord Developer Portal

## Core Functionality

- **discord.py** - Discord API wrapper for bot functionality
- **yt-dlp** - YouTube-DL fork for extracting audio from various sources
- **PyNaCl** - Voice support and encryption for Discord
- **FFmpeg** - Audio processing and encoding (system dependency)
- **Opus** - Audio codec preferred by Discord for voice channels

## Optional Enhancements

- **opuslib** - Direct Opus encoding support for better performance
- **cffi/pycparser** - Required for some audio processing libraries

## Supported Audio Sources

- YouTube (with fallback when blocked)
- SoundCloud 
- Bandcamp
- Direct audio URLs
- Many other sources supported by yt-dlp