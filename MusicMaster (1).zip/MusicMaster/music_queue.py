"""
Music Queue Management
Handles the music queue for each Discord server.
"""

import logging
from collections import deque
from typing import Optional, List, Dict, Any

logger = logging.getLogger(__name__)

class MusicQueue:
    """Manages the music queue for a Discord server."""
    
    def __init__(self):
        self._queue = deque()
        self._current_song = None
        self._history = deque(maxlen=10)  # Keep last 10 songs
    
    def add_song(self, song_info: Dict[str, Any]) -> None:
        """Add a song to the queue.
        
        Args:
            song_info: Dictionary containing song information
        """
        self._queue.append(song_info)
        logger.info(f"Added song to queue: {song_info.get('title', 'Unknown')}")
    
    def get_next_song(self) -> Optional[Dict[str, Any]]:
        """Get and remove the next song from the queue.
        
        Returns:
            Song information dictionary or None if queue is empty
        """
        if self._current_song:
            self._history.append(self._current_song)
        
        if self._queue:
            self._current_song = self._queue.popleft()
            logger.info(f"Retrieved next song: {self._current_song.get('title', 'Unknown')}")
            return self._current_song
        
        self._current_song = None
        return None
    
    def current_song(self) -> Optional[Dict[str, Any]]:
        """Get the currently playing song without removing it.
        
        Returns:
            Current song information or None
        """
        return self._current_song
    
    def peek_next(self) -> Optional[Dict[str, Any]]:
        """Peek at the next song without removing it.
        
        Returns:
            Next song information or None if queue is empty
        """
        return self._queue[0] if self._queue else None
    
    def get_upcoming_songs(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get a list of upcoming songs.
        
        Args:
            limit: Maximum number of songs to return
            
        Returns:
            List of song information dictionaries
        """
        return list(self._queue)[:limit]
    
    def size(self) -> int:
        """Get the number of songs in the queue.
        
        Returns:
            Number of songs in queue
        """
        return len(self._queue)
    
    def is_empty(self) -> bool:
        """Check if the queue is empty.
        
        Returns:
            True if queue is empty, False otherwise
        """
        return len(self._queue) == 0
    
    def clear(self) -> None:
        """Clear all songs from the queue."""
        cleared_count = len(self._queue)
        self._queue.clear()
        self._current_song = None
        logger.info(f"Cleared queue: {cleared_count} songs removed")
    
    def remove_song(self, index: int) -> Optional[Dict[str, Any]]:
        """Remove a song at a specific index.
        
        Args:
            index: Index of the song to remove (0-based)
            
        Returns:
            Removed song information or None if index is invalid
        """
        if 0 <= index < len(self._queue):
            # Convert deque to list, remove item, convert back
            queue_list = list(self._queue)
            removed_song = queue_list.pop(index)
            self._queue = deque(queue_list)
            logger.info(f"Removed song at index {index}: {removed_song.get('title', 'Unknown')}")
            return removed_song
        return None
    
    def move_song(self, from_index: int, to_index: int) -> bool:
        """Move a song from one position to another.
        
        Args:
            from_index: Current index of the song
            to_index: Target index for the song
            
        Returns:
            True if successful, False otherwise
        """
        if (0 <= from_index < len(self._queue) and 
            0 <= to_index < len(self._queue) and 
            from_index != to_index):
            
            queue_list = list(self._queue)
            song = queue_list.pop(from_index)
            queue_list.insert(to_index, song)
            self._queue = deque(queue_list)
            
            logger.info(f"Moved song from index {from_index} to {to_index}: {song.get('title', 'Unknown')}")
            return True
        return False
    
    def shuffle(self) -> None:
        """Shuffle the queue randomly."""
        import random
        queue_list = list(self._queue)
        random.shuffle(queue_list)
        self._queue = deque(queue_list)
        logger.info("Queue shuffled")
    
    def get_history(self) -> List[Dict[str, Any]]:
        """Get the history of recently played songs.
        
        Returns:
            List of recently played songs
        """
        return list(self._history)
    
    def get_total_duration(self) -> int:
        """Get the total duration of all songs in the queue.
        
        Returns:
            Total duration in seconds
        """
        total = 0
        for song in self._queue:
            duration = song.get('duration', 0)
            if duration:
                total += duration
        return total
    
    def search_queue(self, query: str) -> List[tuple]:
        """Search for songs in the queue by title.
        
        Args:
            query: Search query
            
        Returns:
            List of tuples (index, song_info) matching the query
        """
        results = []
        query_lower = query.lower()
        
        for index, song in enumerate(self._queue):
            title = song.get('title', '').lower()
            if query_lower in title:
                results.append((index, song))
        
        return results
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert queue to dictionary for serialization.
        
        Returns:
            Dictionary representation of the queue
        """
        return {
            'queue': list(self._queue),
            'current_song': self._current_song,
            'history': list(self._history),
            'size': self.size()
        }
    
    def from_dict(self, data: Dict[str, Any]) -> None:
        """Load queue from dictionary.
        
        Args:
            data: Dictionary containing queue data
        """
        self._queue = deque(data.get('queue', []))
        self._current_song = data.get('current_song')
        self._history = deque(data.get('history', []), maxlen=10)
        logger.info(f"Loaded queue from data: {self.size()} songs")
