
"""
Web Dashboard for Discord Music Bot Management
Provides a web interface for managing the bot, viewing stats, and controlling playlists.
"""

import asyncio
import json
import logging
import os
from datetime import datetime
from threading import Thread
from typing import Dict, Any, Optional

from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
from flask import send_from_directory
import discord
from music_bot import MusicBot
from playlist_manager import PlaylistManager
from config import BOT_CONFIG

logger = logging.getLogger(__name__)

class BotDashboard:
    def __init__(self, bot: MusicBot):
        self.bot = bot
        self.app = Flask(__name__)
        self.app.secret_key = os.getenv('FLASK_SECRET_KEY', 'your-secret-key-here')
        self.playlist_manager = PlaylistManager()
        self.setup_routes()
        
    def setup_routes(self):
        """Set up all Flask routes."""
        
        @self.app.route('/')
        def index():
            """Main dashboard page."""
            return render_template('dashboard.html', 
                                 bot_status=self.get_bot_status(),
                                 guild_count=len(self.bot.guilds) if self.bot.guilds else 0)
        
        @self.app.route('/api/status')
        def api_status():
            """API endpoint for bot status."""
            return jsonify(self.get_bot_status())
        
        @self.app.route('/servers')
        def servers():
            """View connected servers."""
            servers_data = []
            if self.bot.guilds:
                for guild in self.bot.guilds:
                    queue = self.bot.get_music_queue(guild.id)
                    servers_data.append({
                        'id': guild.id,
                        'name': guild.name,
                        'member_count': guild.member_count,
                        'queue_size': queue.size() if queue else 0,
                        'is_playing': bool(guild.voice_client and guild.voice_client.is_playing()) if guild.voice_client else False
                    })
            return render_template('servers.html', servers=servers_data)
        
        @self.app.route('/playlists')
        def playlists():
            """View all playlists."""
            all_playlists = {}
            if self.bot.guilds:
                for guild in self.bot.guilds:
                    guild_playlists = self.playlist_manager.get_all_playlists(str(guild.id))
                    if guild_playlists:
                        all_playlists[guild.name] = guild_playlists
            return render_template('playlists.html', playlists=all_playlists)
        
        @self.app.route('/playlist/<guild_id>/<playlist_name>')
        def playlist_detail(guild_id, playlist_name):
            """View detailed playlist information."""
            playlist = self.playlist_manager.get_playlist(guild_id, playlist_name)
            if not playlist:
                flash(f'Playlist "{playlist_name}" not found!', 'error')
                return redirect(url_for('playlists'))
            
            guild = discord.utils.get(self.bot.guilds, id=int(guild_id))
            guild_name = guild.name if guild else "Unknown Server"
            
            return render_template('playlist_detail.html', 
                                 playlist=playlist, 
                                 guild_name=guild_name,
                                 guild_id=guild_id)
        
        @self.app.route('/api/playlist/<guild_id>/<playlist_name>/delete', methods=['POST'])
        def api_delete_playlist(guild_id, playlist_name):
            """API endpoint to delete a playlist."""
            try:
                if self.playlist_manager.delete_playlist(guild_id, playlist_name):
                    return jsonify({'success': True, 'message': f'Playlist "{playlist_name}" deleted successfully'})
                else:
                    return jsonify({'success': False, 'message': 'Playlist not found'}), 404
            except Exception as e:
                return jsonify({'success': False, 'message': str(e)}), 500
        
        @self.app.route('/api/playlist/<guild_id>/<playlist_name>/song/<int:song_index>/remove', methods=['POST'])
        def api_remove_song(guild_id, playlist_name, song_index):
            """API endpoint to remove a song from playlist."""
            try:
                if self.playlist_manager.remove_song_from_playlist(guild_id, playlist_name, song_index):
                    return jsonify({'success': True, 'message': 'Song removed successfully'})
                else:
                    return jsonify({'success': False, 'message': 'Failed to remove song'}), 400
            except Exception as e:
                return jsonify({'success': False, 'message': str(e)}), 500
        
        @self.app.route('/logs')
        def logs():
            """View bot logs."""
            try:
                with open('bot.log', 'r') as f:
                    log_content = f.read()
                    # Get last 100 lines
                    lines = log_content.split('\n')
                    recent_logs = lines[-100:] if len(lines) > 100 else lines
                return render_template('logs.html', logs=recent_logs)
            except FileNotFoundError:
                return render_template('logs.html', logs=['No log file found'])
        
        @self.app.route('/api/logs')
        def api_logs():
            """API endpoint for logs."""
            try:
                with open('bot.log', 'r') as f:
                    log_content = f.read()
                    lines = log_content.split('\n')
                    recent_logs = lines[-50:] if len(lines) > 50 else lines
                return jsonify({'logs': recent_logs})
            except FileNotFoundError:
                return jsonify({'logs': ['No log file found']})
        
        @self.app.route('/config')
        def config():
            """View and edit bot configuration."""
            return render_template('config.html', config=BOT_CONFIG)
        
        @self.app.route('/api/config', methods=['POST'])
        def api_update_config():
            """API endpoint to update configuration."""
            try:
                data = request.get_json()
                for key, value in data.items():
                    if key in BOT_CONFIG:
                        # Convert string to appropriate type
                        if isinstance(BOT_CONFIG[key], bool):
                            BOT_CONFIG[key] = str(value).lower() == 'true'
                        elif isinstance(BOT_CONFIG[key], int):
                            BOT_CONFIG[key] = int(value)
                        elif isinstance(BOT_CONFIG[key], float):
                            BOT_CONFIG[key] = float(value)
                        else:
                            BOT_CONFIG[key] = value
                
                return jsonify({'success': True, 'message': 'Configuration updated successfully'})
            except Exception as e:
                return jsonify({'success': False, 'message': str(e)}), 500
    
    def get_bot_status(self) -> Dict[str, Any]:
        """Get comprehensive bot status information."""
        status = {
            'is_ready': self.bot.is_ready(),
            'latency': round(self.bot.latency * 1000, 2),  # Convert to ms
            'guild_count': len(self.bot.guilds) if self.bot.guilds else 0,
            'user_count': sum(guild.member_count for guild in self.bot.guilds) if self.bot.guilds else 0,
            'voice_connections': sum(1 for guild in self.bot.guilds if guild.voice_client) if self.bot.guilds else 0,
            'active_queues': sum(1 for queue in self.bot.music_queues.values() if not queue.is_empty()),
            'total_songs_queued': sum(queue.size() for queue in self.bot.music_queues.values()),
            'uptime': str(datetime.now() - self.bot.start_time) if hasattr(self.bot, 'start_time') else 'Unknown',
            'version': '2.0.0'
        }
        return status
    
    def run(self, host='0.0.0.0', port=5000, debug=False):
        """Run the Flask web dashboard."""
        self.app.run(host=host, port=port, debug=debug, threaded=True)

def start_dashboard(bot: MusicBot):
    """Start the web dashboard in a separate thread."""
    dashboard = BotDashboard(bot)
    
    # Create templates directory if it doesn't exist
    os.makedirs('templates', exist_ok=True)
    os.makedirs('static', exist_ok=True)
    
    # Start the dashboard in a separate thread
    dashboard_thread = Thread(target=dashboard.run, daemon=True)
    dashboard_thread.start()
    
    logger.info("Web dashboard started at http://0.0.0.0:5000")
    return dashboard
