"""
Configuration settings for the Discord Music Bot.
"""

import os
from typing import Dict, Any

# Bot configuration
BOT_CONFIG: Dict[str, Any] = {
    # Command prefix for bot commands
    'command_prefix': os.getenv('BOT_PREFIX', '!'),

    # Bot settings
    'max_queue_size': int(os.getenv('MAX_QUEUE_SIZE', '100')),
    'max_song_duration': int(os.getenv('MAX_SONG_DURATION', '3600')),  # 1 hour in seconds
    'default_volume': float(os.getenv('DEFAULT_VOLUME', '3.0')),

    # Timeout settings (in seconds)
    'voice_timeout': int(os.getenv('VOICE_TIMEOUT', '300')),  # 5 minutes
    'search_timeout': int(os.getenv('SEARCH_TIMEOUT', '30')),  # 30 seconds

    # Audio quality settings
    'audio_quality': os.getenv('AUDIO_QUALITY', 'medium'),  # low, medium, high
    'prefer_opus': os.getenv('PREFER_OPUS', 'true').lower() == 'true',

    # Feature toggles
    'allow_playlists': os.getenv('ALLOW_PLAYLISTS', 'true').lower() == 'true',
    'allow_live_streams': os.getenv('ALLOW_LIVE_STREAMS', 'false').lower() == 'true',
    'enable_vote_skip': os.getenv('ENABLE_VOTE_SKIP', 'false').lower() == 'true',
    'require_same_channel': os.getenv('REQUIRE_SAME_CHANNEL', 'true').lower() == 'true',

    # Logging settings
    'log_level': os.getenv('LOG_LEVEL', 'INFO'),
    'log_commands': os.getenv('LOG_COMMANDS', 'true').lower() == 'true',

    # Rate limiting
    'rate_limit_per_user': int(os.getenv('RATE_LIMIT_PER_USER', '5')),  # commands per minute
    'rate_limit_global': int(os.getenv('RATE_LIMIT_GLOBAL', '50')),     # commands per minute globally
}

# YouTube-DL configuration
YTDL_CONFIG = {
    'format': 'bestaudio/best',
    'extractaudio': True,
    'audioformat': 'mp3',
    'outtmpl': '%(extractor)s-%(id)s-%(title)s.%(ext)s',
    'restrictfilenames': True,
    'noplaylist': not BOT_CONFIG['allow_playlists'],
    'nocheckcertificate': True,
    'ignoreerrors': False,
    'logtostderr': False,
    'quiet': True,
    'no_warnings': True,
    'default_search': 'auto',
    'source_address': '0.0.0.0',
    'age_limit': int(os.getenv('AGE_LIMIT', '18')),
    'max_downloads': int(os.getenv('MAX_DOWNLOADS', '1')),
}

# FFmpeg configuration
FFMPEG_CONFIG = {
    'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',
    'options': '-vn -filter:a "volume={}"'.format(BOT_CONFIG['default_volume'])
}

# Audio quality settings
AUDIO_QUALITY_MAP = {
    'low': {
        'format': 'worst[abr<=96]',
        'audio_bitrate': '96k'
    },
    'medium': {
        'format': 'best[abr<=128]',
        'audio_bitrate': '128k'
    },
    'high': {
        'format': 'best[abr<=256]',
        'audio_bitrate': '256k'
    }
}

# Update YTDL config with quality settings
if BOT_CONFIG['audio_quality'] in AUDIO_QUALITY_MAP:
    quality_settings = AUDIO_QUALITY_MAP[BOT_CONFIG['audio_quality']]
    YTDL_CONFIG.update(quality_settings)

# Supported domains for music extraction
SUPPORTED_DOMAINS = [
    'youtube.com',
    'youtu.be',
    'soundcloud.com',
    'bandcamp.com',
    'vimeo.com',
    'twitch.tv',
    'mixer.com',
    'dailymotion.com'
]

# Error messages
ERROR_MESSAGES = {
    'not_in_voice': "❌ You need to be in a voice channel to use this command!",
    'bot_not_connected': "❌ I'm not connected to a voice channel!",
    'nothing_playing': "❌ Nothing is currently playing!",
    'queue_empty': "📋 The queue is empty!",
    'invalid_url': "❌ Invalid URL or unsupported platform!",
    'search_failed': "❌ Failed to find any results for your search!",
    'queue_full': f"❌ Queue is full! Maximum {BOT_CONFIG['max_queue_size']} songs allowed.",
    'song_too_long': f"❌ Song is too long! Maximum duration is {BOT_CONFIG['max_song_duration']} seconds.",
    'rate_limited': "❌ You're being rate limited! Please wait before using commands.",
    'permission_denied': "❌ You don't have permission to use this command!",
    'same_channel_required': "❌ You must be in the same voice channel as the bot!",
    'extraction_failed': "❌ Failed to extract audio from the provided source!",
    'connection_failed': "❌ Failed to connect to the voice channel!",
    'playback_error': "❌ An error occurred during playback!"
}

# Success messages
SUCCESS_MESSAGES = {
    'joined_channel': "✅ Joined voice channel: **{}**",
    'left_channel': "✅ Left voice channel: **{}**",
    'song_added': "📋 Added to queue: **{}**",
    'now_playing': "▶️ Now playing: **{}**",
    'playback_paused': "⏸️ Playback paused!",
    'playback_resumed': "▶️ Playback resumed!",
    'song_skipped': "⏭️ Skipped current song!",
    'playback_stopped': "⏹️ Playback stopped!",
    'queue_cleared': "🗑️ Queue cleared!",
    'queue_shuffled': "🔀 Queue shuffled!"
}

# Embed colors
EMBED_COLORS = {
    'default': 0x3498db,      # Blue
    'success': 0x2ecc71,      # Green
    'error': 0xe74c3c,        # Red
    'warning': 0xf39c12,      # Orange
    'info': 0x9b59b6,         # Purple
    'music': 0x1db954,        # Spotify Green
}

# Emoji configuration
EMOJIS = {
    'play': '▶️',
    'pause': '⏸️',
    'stop': '⏹️',
    'skip': '⏭️',
    'previous': '⏮️',
    'repeat': '🔁',
    'shuffle': '🔀',
    'volume_up': '🔊',
    'volume_down': '🔉',
    'mute': '🔇',
    'queue': '📋',
    'music': '🎵',
    'note': '🎶',
    'search': '🔍',
    'loading': '⏳',
    'success': '✅',
    'error': '❌',
    'warning': '⚠️',
    'info': 'ℹ️'
}

def get_config_value(key: str, default: Any = None) -> Any:
    """Get configuration value with fallback.

    Args:
        key: Configuration key
        default: Default value if key not found

    Returns:
        Configuration value
    """
    return BOT_CONFIG.get(key, default)

def validate_config() -> bool:
    """Validate configuration settings.

    Returns:
        True if configuration is valid, False otherwise
    """
    # Check required environment variables
    required_env_vars = ['DISCORD_BOT_TOKEN']

    for var in required_env_vars:
        if not os.getenv(var):
            print(f"ERROR: Required environment variable {var} is not set!")
            return False

    # Validate numeric values
    try:
        assert BOT_CONFIG['max_queue_size'] > 0
        assert BOT_CONFIG['max_song_duration'] > 0
        assert 0.0 <= BOT_CONFIG['default_volume'] <= 1.0
        assert BOT_CONFIG['voice_timeout'] > 0
        assert BOT_CONFIG['search_timeout'] > 0
    except (ValueError, AssertionError) as e:
        print(f"ERROR: Invalid configuration value: {e}")
        return False

    return True

# Initialize configuration validation
if __name__ == "__main__":
    if validate_config():
        print("✅ Configuration is valid!")
    else:
        print("❌ Configuration validation failed!")