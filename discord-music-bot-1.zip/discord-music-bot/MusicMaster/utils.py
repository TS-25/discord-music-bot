"""
Utility functions for the Discord Music Bot.
"""

import re
import logging
from typing import Optional
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

def format_duration(duration: Optional[int]) -> str:
    """Format duration in seconds to MM:SS or HH:MM:SS format.
    
    Args:
        duration: Duration in seconds
        
    Returns:
        Formatted duration string
    """
    if not duration or duration <= 0:
        return "00:00"
    
    hours = duration // 3600
    minutes = (duration % 3600) // 60
    seconds = duration % 60
    
    if hours > 0:
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
    else:
        return f"{minutes:02d}:{seconds:02d}"

def is_url(text: str) -> bool:
    """Check if text is a valid URL.
    
    Args:
        text: Text to check
        
    Returns:
        True if text is a URL, False otherwise
    """
    try:
        result = urlparse(text)
        return all([result.scheme, result.netloc])
    except Exception:
        return False

def is_youtube_url(url: str) -> bool:
    """Check if URL is a YouTube URL.
    
    Args:
        url: URL to check
        
    Returns:
        True if URL is from YouTube, False otherwise
    """
    youtube_domains = [
        'youtube.com',
        'www.youtube.com',
        'm.youtube.com',
        'youtu.be',
        'music.youtube.com'
    ]
    
    try:
        parsed = urlparse(url)
        return parsed.netloc.lower() in youtube_domains
    except Exception:
        return False

def extract_video_id(url: str) -> Optional[str]:
    """Extract YouTube video ID from URL.
    
    Args:
        url: YouTube URL
        
    Returns:
        Video ID if found, None otherwise
    """
    # YouTube URL patterns
    patterns = [
        r'(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})',
        r'youtube\.com\/watch\?.*v=([a-zA-Z0-9_-]{11})',
        r'youtu\.be\/([a-zA-Z0-9_-]{11})'
    ]
    
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return match.group(1)
    
    return None

def sanitize_filename(filename: str) -> str:
    """Sanitize filename by removing invalid characters.
    
    Args:
        filename: Original filename
        
    Returns:
        Sanitized filename
    """
    # Remove invalid characters for filenames
    invalid_chars = r'[<>:"/\\|?*]'
    sanitized = re.sub(invalid_chars, '_', filename)
    
    # Remove multiple consecutive underscores
    sanitized = re.sub(r'_+', '_', sanitized)
    
    # Remove leading/trailing underscores and dots
    sanitized = sanitized.strip('_.')
    
    # Limit length
    if len(sanitized) > 200:
        sanitized = sanitized[:200]
    
    return sanitized or "unknown"

def parse_time(time_str: str) -> Optional[int]:
    """Parse time string to seconds.
    
    Args:
        time_str: Time string (e.g., "1:30", "1h30m", "90s")
        
    Returns:
        Time in seconds, None if invalid
    """
    if not time_str:
        return None
    
    time_str = time_str.lower().strip()
    
    # Handle MM:SS or HH:MM:SS format
    if ':' in time_str:
        parts = time_str.split(':')
        try:
            if len(parts) == 2:  # MM:SS
                minutes, seconds = map(int, parts)
                return minutes * 60 + seconds
            elif len(parts) == 3:  # HH:MM:SS
                hours, minutes, seconds = map(int, parts)
                return hours * 3600 + minutes * 60 + seconds
        except ValueError:
            pass
    
    # Handle units (1h30m20s, 90s, 5m, etc.)
    total_seconds = 0
    
    # Hours
    hours_match = re.search(r'(\d+)h', time_str)
    if hours_match:
        total_seconds += int(hours_match.group(1)) * 3600
    
    # Minutes
    minutes_match = re.search(r'(\d+)m', time_str)
    if minutes_match:
        total_seconds += int(minutes_match.group(1)) * 60
    
    # Seconds
    seconds_match = re.search(r'(\d+)s', time_str)
    if seconds_match:
        total_seconds += int(seconds_match.group(1))
    
    # If no units found, try parsing as plain number (assume seconds)
    if total_seconds == 0:
        try:
            total_seconds = int(time_str)
        except ValueError:
            return None
    
    return total_seconds if total_seconds > 0 else None

def format_file_size(size_bytes: int) -> str:
    """Format file size in bytes to human readable format.
    
    Args:
        size_bytes: Size in bytes
        
    Returns:
        Formatted size string
    """
    if size_bytes == 0:
        return "0 B"
    
    units = ["B", "KB", "MB", "GB", "TB"]
    unit_index = 0
    size = float(size_bytes)
    
    while size >= 1024 and unit_index < len(units) - 1:
        size /= 1024
        unit_index += 1
    
    return f"{size:.1f} {units[unit_index]}"

def truncate_text(text: str, max_length: int = 100) -> str:
    """Truncate text to specified length with ellipsis.
    
    Args:
        text: Text to truncate
        max_length: Maximum length
        
    Returns:
        Truncated text
    """
    if len(text) <= max_length:
        return text
    return text[:max_length - 3] + "..."

def create_progress_bar(current: int, total: int, length: int = 20) -> str:
    """Create a progress bar string.
    
    Args:
        current: Current progress
        total: Total amount
        length: Length of progress bar
        
    Returns:
        Progress bar string
    """
    if total <= 0:
        return "█" * length
    
    progress = current / total
    filled_length = int(length * progress)
    
    bar = "█" * filled_length + "░" * (length - filled_length)
    percentage = int(progress * 100)
    
    return f"{bar} {percentage}%"

def validate_search_query(query: str) -> bool:
    """Validate search query.
    
    Args:
        query: Search query to validate
        
    Returns:
        True if valid, False otherwise
    """
    if not query or not query.strip():
        return False
    
    # Check length
    if len(query.strip()) > 500:
        return False
    
    # Check for only whitespace or special characters
    if not re.search(r'[a-zA-Z0-9]', query):
        return False
    
    return True

def get_platform_from_url(url: str) -> Optional[str]:
    """Identify the platform from URL.
    
    Args:
        url: URL to analyze
        
    Returns:
        Platform name or None if unknown
    """
    if not is_url(url):
        return None
    
    domain = urlparse(url).netloc.lower()
    
    platform_map = {
        'youtube.com': 'YouTube',
        'www.youtube.com': 'YouTube',
        'm.youtube.com': 'YouTube',
        'youtu.be': 'YouTube',
        'music.youtube.com': 'YouTube Music',
        'soundcloud.com': 'SoundCloud',
        'www.soundcloud.com': 'SoundCloud',
        'spotify.com': 'Spotify',
        'open.spotify.com': 'Spotify',
        'bandcamp.com': 'Bandcamp'
    }
    
    for domain_key, platform in platform_map.items():
        if domain_key in domain:
            return platform
    
    return "Unknown"

def log_command_usage(ctx, command_name: str, **kwargs):
    """Log command usage for analytics.
    
    Args:
        ctx: Discord context
        command_name: Name of the command
        **kwargs: Additional parameters to log
    """
    guild_name = ctx.guild.name if ctx.guild else "DM"
    user = f"{ctx.author.name}#{ctx.author.discriminator}"
    
    log_data = {
        'command': command_name,
        'user': user,
        'guild': guild_name,
        'channel': ctx.channel.name if hasattr(ctx.channel, 'name') else str(ctx.channel),
        **kwargs
    }
    
    logger.info(f"Command used: {log_data}")
