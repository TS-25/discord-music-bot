#!/usr/bin/env python3
"""
Discord Music Bot - Main Entry Point
A Discord bot that can join voice channels and play music from various sources.
"""

import asyncio
import logging
import os
import sys
from datetime import datetime
from music_bot import MusicBot
from web_dashboard import start_dashboard

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('bot.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)

async def main():
    """Main function to run the Discord music bot."""
    try:
        # Get Discord bot token from environment variables
        token = os.getenv('DISCORD_BOT_TOKEN')
        if not token:
            logger.error("DISCORD_BOT_TOKEN environment variable not found!")
            logger.error("Please set your Discord bot token in the environment variables.")
            return
        
        # Create and run the music bot
        bot = MusicBot()
        bot.start_time = datetime.now()  # Track start time for uptime
        
        # Start web dashboard
        start_dashboard(bot)
        
        logger.info("Starting Discord Music Bot...")
        logger.info("Web dashboard available at: http://0.0.0.0:5000")
        await bot.start(token)
        
    except KeyboardInterrupt:
        logger.info("Bot shutdown requested by user.")
    except Exception as e:
        logger.error(f"An error occurred while running the bot: {e}")
        raise

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped.")
    except Exception as e:
        logger.error(f"Failed to start bot: {e}")
