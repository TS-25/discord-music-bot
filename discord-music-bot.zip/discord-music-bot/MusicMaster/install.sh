
#!/bin/bash

echo "🎵 Discord Music Bot Installation Script"
echo "========================================"

# Check if we're in the MusicMaster directory
if [ ! -f "main.py" ]; then
    echo "❌ Error: Please run this script from the MusicMaster directory"
    exit 1
fi

echo "📦 Installing system dependencies..."
# Install system packages via nix-env (Replit's package manager)
nix-env -iA nixpkgs.ffmpeg
nix-env -iA nixpkgs.opus

echo "🐍 Installing Python dependencies..."
# Install Python packages
pip install discord.py>=2.5.0
pip install yt-dlp>=2025.6.30
pip install PyNaCl>=1.5.0
pip install aiohttp>=3.8.0
pip install flask>=2.0.0
pip install cffi>=1.15.0

echo "🔧 Setting up configuration..."
# Create environment file template if it doesn't exist
if [ ! -f ".env" ]; then
    cat > .env << 'EOF'
# Discord Bot Configuration
DISCORD_BOT_TOKEN=your_bot_token_here

# Bot Settings (optional - defaults will be used if not set)
BOT_PREFIX=!
MAX_QUEUE_SIZE=100
DEFAULT_VOLUME=0.5
VOICE_TIMEOUT=300

# Audio Quality (low, medium, high)
AUDIO_QUALITY=medium
PREFER_OPUS=true

# Features
ALLOW_PLAYLISTS=true
REQUIRE_SAME_CHANNEL=true
ENABLE_VOTE_SKIP=false

# Logging
LOG_LEVEL=INFO
LOG_COMMANDS=true
EOF
    echo "📝 Created .env file template. Please edit it with your Discord bot token."
else
    echo "✅ .env file already exists"
fi

# Create playlists directory if it doesn't exist
mkdir -p playlists

echo ""
echo "✅ Installation complete!"
echo ""
echo "📋 Next steps:"
echo "1. Edit the .env file and add your Discord bot token"
echo "2. Get your bot token from: https://discord.com/developers/applications"
echo "3. Run the bot with: python3 main.py"
echo ""
echo "🌐 The web dashboard will be available at: http://0.0.0.0:5000"
echo ""
echo "🎵 Available commands:"
echo "   !join    - Join voice channel"
echo "   !play    - Play music"
echo "   !queue   - Show queue"
echo "   !help    - Show all commands"
