"""
Playlist Management System
Handles creation, saving, loading, and management of music playlists for Discord servers.
"""

import json
import os
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime

logger = logging.getLogger(__name__)

class PlaylistManager:
    """Manages playlists for Discord servers."""
    
    def __init__(self, data_dir: str = "playlists"):
        """Initialize playlist manager.
        
        Args:
            data_dir: Directory to store playlist data
        """
        self.data_dir = data_dir
        self.playlists: Dict[str, Dict[str, Any]] = {}  # guild_id -> {playlist_name -> playlist_data}
        self._ensure_data_directory()
        self._load_all_playlists()
    
    def _ensure_data_directory(self) -> None:
        """Ensure the data directory exists."""
        if not os.path.exists(self.data_dir):
            os.makedirs(self.data_dir)
            logger.info(f"Created playlist data directory: {self.data_dir}")
    
    def _get_playlist_file(self, guild_id: str) -> str:
        """Get the playlist file path for a guild.
        
        Args:
            guild_id: Discord guild ID
            
        Returns:
            File path for guild's playlists
        """
        return os.path.join(self.data_dir, f"guild_{guild_id}.json")
    
    def _load_guild_playlists(self, guild_id: str) -> None:
        """Load playlists for a specific guild.
        
        Args:
            guild_id: Discord guild ID
        """
        file_path = self._get_playlist_file(guild_id)
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    self.playlists[guild_id] = json.load(f)
                logger.info(f"Loaded playlists for guild {guild_id}")
            except Exception as e:
                logger.error(f"Error loading playlists for guild {guild_id}: {e}")
                self.playlists[guild_id] = {}
        else:
            self.playlists[guild_id] = {}
    
    def _load_all_playlists(self) -> None:
        """Load all existing playlists from files."""
        if not os.path.exists(self.data_dir):
            return
        
        for filename in os.listdir(self.data_dir):
            if filename.startswith("guild_") and filename.endswith(".json"):
                guild_id = filename[6:-5]  # Remove "guild_" prefix and ".json" suffix
                self._load_guild_playlists(guild_id)
    
    def _save_guild_playlists(self, guild_id: str) -> bool:
        """Save playlists for a specific guild.
        
        Args:
            guild_id: Discord guild ID
            
        Returns:
            True if saved successfully, False otherwise
        """
        try:
            file_path = self._get_playlist_file(guild_id)
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(self.playlists.get(guild_id, {}), f, indent=2, ensure_ascii=False)
            logger.info(f"Saved playlists for guild {guild_id}")
            return True
        except Exception as e:
            logger.error(f"Error saving playlists for guild {guild_id}: {e}")
            return False
    
    def create_playlist(self, guild_id: str, name: str, creator_id: str, description: str = "") -> bool:
        """Create a new playlist.
        
        Args:
            guild_id: Discord guild ID
            name: Playlist name
            creator_id: Discord user ID of creator
            description: Optional playlist description
            
        Returns:
            True if created successfully, False if playlist already exists
        """
        if guild_id not in self.playlists:
            self.playlists[guild_id] = {}
        
        if name.lower() in [p.lower() for p in self.playlists[guild_id].keys()]:
            return False  # Playlist already exists
        
        playlist_data = {
            "name": name,
            "description": description,
            "creator_id": creator_id,
            "created_at": datetime.now().isoformat(),
            "modified_at": datetime.now().isoformat(),
            "songs": [],
            "play_count": 0
        }
        
        self.playlists[guild_id][name] = playlist_data
        self._save_guild_playlists(guild_id)
        logger.info(f"Created playlist '{name}' in guild {guild_id}")
        return True
    
    def delete_playlist(self, guild_id: str, name: str) -> bool:
        """Delete a playlist.
        
        Args:
            guild_id: Discord guild ID
            name: Playlist name
            
        Returns:
            True if deleted successfully, False if playlist doesn't exist
        """
        if guild_id not in self.playlists:
            return False
        
        # Find playlist with case-insensitive search
        actual_name = None
        for playlist_name in self.playlists[guild_id].keys():
            if playlist_name.lower() == name.lower():
                actual_name = playlist_name
                break
        
        if actual_name:
            del self.playlists[guild_id][actual_name]
            self._save_guild_playlists(guild_id)
            logger.info(f"Deleted playlist '{actual_name}' from guild {guild_id}")
            return True
        
        return False
    
    def add_song_to_playlist(self, guild_id: str, playlist_name: str, song_info: Dict[str, Any]) -> bool:
        """Add a song to a playlist.
        
        Args:
            guild_id: Discord guild ID
            playlist_name: Name of the playlist
            song_info: Song information dictionary
            
        Returns:
            True if added successfully, False if playlist doesn't exist
        """
        playlist = self.get_playlist(guild_id, playlist_name)
        if not playlist:
            return False
        
        # Add timestamp to song
        song_with_timestamp = song_info.copy()
        song_with_timestamp["added_at"] = datetime.now().isoformat()
        
        playlist["songs"].append(song_with_timestamp)
        playlist["modified_at"] = datetime.now().isoformat()
        
        self._save_guild_playlists(guild_id)
        logger.info(f"Added song '{song_info.get('title', 'Unknown')}' to playlist '{playlist_name}'")
        return True
    
    def remove_song_from_playlist(self, guild_id: str, playlist_name: str, song_index: int) -> bool:
        """Remove a song from a playlist by index.
        
        Args:
            guild_id: Discord guild ID
            playlist_name: Name of the playlist
            song_index: Index of song to remove (0-based)
            
        Returns:
            True if removed successfully, False otherwise
        """
        playlist = self.get_playlist(guild_id, playlist_name)
        if not playlist or song_index < 0 or song_index >= len(playlist["songs"]):
            return False
        
        removed_song = playlist["songs"].pop(song_index)
        playlist["modified_at"] = datetime.now().isoformat()
        
        self._save_guild_playlists(guild_id)
        logger.info(f"Removed song '{removed_song.get('title', 'Unknown')}' from playlist '{playlist_name}'")
        return True
    
    def get_playlist(self, guild_id: str, name: str) -> Optional[Dict[str, Any]]:
        """Get a playlist by name.
        
        Args:
            guild_id: Discord guild ID
            name: Playlist name
            
        Returns:
            Playlist data or None if not found
        """
        if guild_id not in self.playlists:
            self._load_guild_playlists(guild_id)
        
        # Case-insensitive search
        for playlist_name, playlist_data in self.playlists[guild_id].items():
            if playlist_name.lower() == name.lower():
                return playlist_data
        
        return None
    
    def get_playlist_names(self, guild_id: str) -> List[str]:
        """Get all playlist names for a guild.
        
        Args:
            guild_id: Discord guild ID
            
        Returns:
            List of playlist names
        """
        if guild_id not in self.playlists:
            self._load_guild_playlists(guild_id)
        
        return list(self.playlists[guild_id].keys())
    
    def get_all_playlists(self, guild_id: str) -> Dict[str, Any]:
        """Get all playlists for a guild.
        
        Args:
            guild_id: Discord guild ID
            
        Returns:
            Dictionary of all playlists
        """
        if guild_id not in self.playlists:
            self._load_guild_playlists(guild_id)
        
        return self.playlists[guild_id].copy()
    
    def rename_playlist(self, guild_id: str, old_name: str, new_name: str) -> bool:
        """Rename a playlist.
        
        Args:
            guild_id: Discord guild ID
            old_name: Current playlist name
            new_name: New playlist name
            
        Returns:
            True if renamed successfully, False otherwise
        """
        if guild_id not in self.playlists:
            return False
        
        # Check if new name already exists
        if new_name.lower() in [p.lower() for p in self.playlists[guild_id].keys()]:
            return False
        
        # Find old playlist with case-insensitive search
        actual_old_name = None
        for playlist_name in self.playlists[guild_id].keys():
            if playlist_name.lower() == old_name.lower():
                actual_old_name = playlist_name
                break
        
        if actual_old_name:
            playlist_data = self.playlists[guild_id][actual_old_name]
            playlist_data["name"] = new_name
            playlist_data["modified_at"] = datetime.now().isoformat()
            
            # Move to new key
            self.playlists[guild_id][new_name] = playlist_data
            del self.playlists[guild_id][actual_old_name]
            
            self._save_guild_playlists(guild_id)
            logger.info(f"Renamed playlist '{actual_old_name}' to '{new_name}' in guild {guild_id}")
            return True
        
        return False
    
    def increment_play_count(self, guild_id: str, playlist_name: str) -> None:
        """Increment the play count for a playlist.
        
        Args:
            guild_id: Discord guild ID
            playlist_name: Name of the playlist
        """
        playlist = self.get_playlist(guild_id, playlist_name)
        if playlist:
            playlist["play_count"] = playlist.get("play_count", 0) + 1
            playlist["modified_at"] = datetime.now().isoformat()
            self._save_guild_playlists(guild_id)
    
    def search_playlists(self, guild_id: str, query: str) -> List[str]:
        """Search for playlists by name or description.
        
        Args:
            guild_id: Discord guild ID
            query: Search query
            
        Returns:
            List of matching playlist names
        """
        if guild_id not in self.playlists:
            self._load_guild_playlists(guild_id)
        
        query_lower = query.lower()
        matching_playlists = []
        
        for name, data in self.playlists[guild_id].items():
            if (query_lower in name.lower() or 
                query_lower in data.get("description", "").lower()):
                matching_playlists.append(name)
        
        return matching_playlists
    
    def get_playlist_stats(self, guild_id: str, playlist_name: str) -> Optional[Dict[str, Any]]:
        """Get statistics for a playlist.
        
        Args:
            guild_id: Discord guild ID
            playlist_name: Name of the playlist
            
        Returns:
            Dictionary with playlist statistics
        """
        playlist = self.get_playlist(guild_id, playlist_name)
        if not playlist:
            return None
        
        songs = playlist.get("songs", [])
        total_duration = sum(song.get("duration", 0) for song in songs if song.get("duration"))
        
        return {
            "name": playlist["name"],
            "song_count": len(songs),
            "total_duration": total_duration,
            "play_count": playlist.get("play_count", 0),
            "created_at": playlist["created_at"],
            "modified_at": playlist["modified_at"],
            "creator_id": playlist["creator_id"]
        }