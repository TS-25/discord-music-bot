"""
Discord Music Bot - Main Bot Class
Handles Discord bot functionality, commands, and voice channel management.
"""

import asyncio
import logging
import discord
from discord.ext import commands
import yt_dlp
from music_queue import MusicQueue
from playlist_manager import PlaylistManager
from utils import format_duration, is_url
from config import BOT_CONFIG

logger = logging.getLogger(__name__)

class MusicBot(commands.Bot):
    """Main Discord Music Bot class."""

    def __init__(self):
        # Set up bot intents
        intents = discord.Intents.default()
        intents.message_content = True
        intents.voice_states = True

        super().__init__(
            command_prefix=BOT_CONFIG['command_prefix'],
            intents=intents,
            help_command=None
        )

        # Bot state
        self.music_queues = {}  # Guild ID -> MusicQueue
        self.playlist_manager = PlaylistManager()  # Playlist management

        # YouTube-DL options with better anti-bot measures
        self.ytdl_options = {
            'format': 'bestaudio/best',
            'extractaudio': True,
            'audioformat': 'mp3',
            'outtmpl': '%(extractor)s-%(id)s-%(title)s.%(ext)s',
            'restrictfilenames': True,
            'noplaylist': True,
            'nocheckcertificate': True,
            'ignoreerrors': False,
            'logtostderr': False,
            'quiet': True,
            'no_warnings': True,
            'default_search': 'ytsearch',
            'source_address': '0.0.0.0',
            'cookiefile': None,
            'extractor_retries': 3,
            'fragment_retries': 3,
            'sleep_interval': 1,
            'max_sleep_interval': 5,
            'http_headers': {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-us,en;q=0.5',
                'Accept-Encoding': 'gzip, deflate',
                'DNT': '1',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1'
            },
            'age_limit': 99,
            'geo_bypass': True,
            'geo_bypass_country': 'US'
        }

        # FFmpeg options
        self.ffmpeg_options = {
            'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5 -nostdin',
            'options': '-vn -filter:a "volume=3.0"'
        }

        self.ytdl = yt_dlp.YoutubeDL(self.ytdl_options)

        # Add commands
        self.add_commands()

    async def on_ready(self):
        """Called when the bot is ready."""
        logger.info(f'{self.user} has connected to Discord!')
        logger.info(f'Bot is in {len(self.guilds)} servers')

        # Set bot status
        activity = discord.Activity(
            type=discord.ActivityType.listening,
            name="music | !help"
        )
        await self.change_presence(activity=activity)

    async def on_command_error(self, ctx, error):
        """Handle command errors."""
        if isinstance(error, commands.CommandNotFound):
            await ctx.send("❌ Command not found. Use `!help` to see available commands.")
        elif isinstance(error, commands.MissingRequiredArgument):
            await ctx.send("❌ Missing required argument. Check command usage with `!help`.")
        elif isinstance(error, commands.CommandInvokeError):
            logger.error(f"Command error in {ctx.command}: {error.original}")
            await ctx.send(f"❌ An error occurred: {error.original}")
        else:
            logger.error(f"Unhandled error: {error}")
            await ctx.send("❌ An unexpected error occurred.")

    def get_music_queue(self, guild_id):
        """Get or create music queue for a guild."""
        if guild_id not in self.music_queues:
            self.music_queues[guild_id] = MusicQueue()
        return self.music_queues[guild_id]

    async def join_voice_channel(self, ctx):
        """Join the user's voice channel."""
        if not ctx.author.voice:
            await ctx.send("❌ You need to be in a voice channel!")
            return None

        channel = ctx.author.voice.channel

        # Check if bot is already in a voice channel
        if ctx.guild.voice_client:
            if ctx.guild.voice_client.channel == channel:
                return ctx.guild.voice_client
            else:
                await ctx.guild.voice_client.move_to(channel)
                return ctx.guild.voice_client

        # Join the voice channel
        try:
            voice_client = await channel.connect()
            logger.info(f"Joined voice channel: {channel.name} in {ctx.guild.name}")
            return voice_client
        except Exception as e:
            logger.error(f"Failed to join voice channel: {e}")
            await ctx.send(f"❌ Failed to join voice channel: {e}")
            return None

    async def extract_audio_info(self, search_query):
        """Extract audio information from URL or search query."""
        loop = asyncio.get_event_loop()

        # Try multiple search strategies
        search_strategies = []

        if is_url(search_query):
            search_strategies.append(search_query)
        else:
            # Try different search prefixes
            search_strategies.extend([
                f"ytsearch:{search_query}",
                f"ytsearch1:{search_query}",
                f"ytsearch2:{search_query}",
                f"scsearch:{search_query}",  # SoundCloud
            ])

        for strategy in search_strategies:
            try:
                logger.info(f"Trying search strategy: {strategy}")

                # Run ytdl extract_info in executor to avoid blocking
                data = await loop.run_in_executor(
                    None,
                    lambda s=strategy: self.ytdl.extract_info(s, download=False)
                )

                if 'entries' in data and data['entries']:
                    # Playlist or search results - take first entry
                    data = data['entries'][0]
                elif 'entries' in data and not data['entries']:
                    continue  # Try next strategy

                # Validate that we have a playable URL
                if not data.get('url'):
                    logger.warning(f"No URL found in data for strategy '{strategy}'")
                    continue

                return {
                    'url': data['url'],
                    'title': data.get('title', 'Unknown'),
                    'duration': data.get('duration', 0),
                    'thumbnail': data.get('thumbnail'),
                    'webpage_url': data.get('webpage_url')
                }
            except Exception as e:
                logger.warning(f"Search strategy '{strategy}' failed: {e}")
                continue

        # If all strategies failed
        raise Exception(f"Could not find or play '{search_query}'. YouTube may be blocking requests. Try:\n" +
                       "• Using a direct URL from SoundCloud, Bandcamp, or other sites\n" +
                       "• Trying a different song name\n" +
                       "• Waiting a few minutes and trying again")

    def add_commands(self):
        """Add all bot commands."""

        @self.command(name='join', aliases=['j'])
        async def join(ctx):
            """Join the voice channel."""
            voice_client = await self.join_voice_channel(ctx)
            if voice_client:
                await ctx.send(f"✅ Joined voice channel: **{voice_client.channel.name}**")

        @self.command(name='leave', aliases=['disconnect', 'dc'])
        async def leave(ctx):
            """Leave the voice channel."""
            if ctx.guild.voice_client:
                channel_name = ctx.guild.voice_client.channel.name
                await ctx.guild.voice_client.disconnect()

                # Clear the queue
                queue = self.get_music_queue(ctx.guild.id)
                queue.clear()

                await ctx.send(f"✅ Left voice channel: **{channel_name}**")
                logger.info(f"Left voice channel: {channel_name} in {ctx.guild.name}")
            else:
                await ctx.send("❌ Not connected to a voice channel!")

        @self.command(name='play', aliases=['p'])
        async def play(ctx, *, search_query: str):
            """Play music from URL or search query."""
            # Join voice channel if not already connected
            voice_client = await self.join_voice_channel(ctx)
            if not voice_client:
                return

            # Send initial message
            loading_msg = await ctx.send(f"🔍 Searching for: **{search_query}**...")

            try:
                # Extract audio information
                audio_info = await self.extract_audio_info(search_query)

                # Get music queue
                queue = self.get_music_queue(ctx.guild.id)

                # Add to queue
                queue.add_song(audio_info)

                # Update loading message
                if queue.is_empty() or not voice_client.is_playing():
                    await loading_msg.edit(content=f"▶️ Now playing: **{audio_info['title']}**")
                    await self.play_next_song(ctx)
                else:
                    position = queue.size()
                    await loading_msg.edit(
                        content=f"📋 Added to queue (#{position}): **{audio_info['title']}**"
                    )

            except Exception as e:
                logger.error(f"Error playing music: {e}")
                await loading_msg.edit(content=f"❌ Error: {str(e)}")

        @self.command(name='skip', aliases=['s', 'next'])
        async def skip(ctx):
            """Skip the current song."""
            if ctx.guild.voice_client and ctx.guild.voice_client.is_playing():
                ctx.guild.voice_client.stop()
                await ctx.send("⏭️ Skipped current song!")
            else:
                await ctx.send("❌ Nothing is currently playing!")

        @self.command(name='stop')
        async def stop(ctx):
            """Stop playback and clear the queue."""
            if ctx.guild.voice_client:
                queue = self.get_music_queue(ctx.guild.id)
                queue.clear()
                ctx.guild.voice_client.stop()
                await ctx.send("⏹️ Stopped playback and cleared queue!")
            else:
                await ctx.send("❌ Not connected to a voice channel!")

        @self.command(name='pause')
        async def pause(ctx):
            """Pause the current song."""
            if ctx.guild.voice_client and ctx.guild.voice_client.is_playing():
                ctx.guild.voice_client.pause()
                await ctx.send("⏸️ Paused playback!")
            else:
                await ctx.send("❌ Nothing is currently playing!")

        @self.command(name='resume', aliases=['unpause'])
        async def resume(ctx):
            """Resume the current song."""
            if ctx.guild.voice_client and ctx.guild.voice_client.is_paused():
                ctx.guild.voice_client.resume()
                await ctx.send("▶️ Resumed playback!")
            else:
                await ctx.send("❌ Nothing is currently paused!")

        @self.command(name='queue', aliases=['q'])
        async def show_queue(ctx):
            """Show the current music queue."""
            queue = self.get_music_queue(ctx.guild.id)

            if queue.is_empty():
                await ctx.send("📋 Queue is empty!")
                return

            embed = discord.Embed(
                title="🎵 Music Queue",
                color=discord.Color.blue()
            )

            # Current song
            if ctx.guild.voice_client and ctx.guild.voice_client.is_playing():
                current = queue.current_song()
                if current:
                    embed.add_field(
                        name="▶️ Now Playing",
                        value=f"**{current['title']}**\nDuration: {format_duration(current['duration'])}",
                        inline=False
                    )

            # Upcoming songs
            upcoming = queue.get_upcoming_songs(5)  # Show next 5 songs
            if upcoming:
                queue_text = ""
                for i, song in enumerate(upcoming, 1):
                    queue_text += f"{i}. **{song['title']}** ({format_duration(song['duration'])})\n"

                embed.add_field(
                    name="📋 Up Next",
                    value=queue_text,
                    inline=False
                )

            embed.set_footer(text=f"Total songs in queue: {queue.size()}")
            await ctx.send(embed=embed)

        @self.command(name='clear')
        async def clear_queue(ctx):
            """Clear the music queue."""
            queue = self.get_music_queue(ctx.guild.id)
            queue.clear()
            await ctx.send("🗑️ Cleared the music queue!")

        @self.command(name='volume', aliases=['vol'])
        async def volume(ctx, volume: int = None):
            """Set or check the playback volume (0-100)."""
            if volume is None:
                current_vol = int(BOT_CONFIG.get('default_volume', 0.5) * 100)
                await ctx.send(f"🔊 Current volume: **{current_vol}%**")
                return

            if volume < 0 or volume > 100:
                await ctx.send("❌ Volume must be between 0 and 100!")
                return

            # Update volume in config
            BOT_CONFIG['default_volume'] = volume / 100.0

            # If something is playing, we need to restart it with new volume
            if ctx.guild.voice_client and ctx.guild.voice_client.is_playing():
                await ctx.send(f"🔊 Volume set to **{volume}%**\n⚠️ New volume will apply to the next song.")
            else:
                await ctx.send(f"🔊 Volume set to **{volume}%**")

        @self.command(name='nowplaying', aliases=['np', 'current'])
        async def nowplaying(ctx):
            """Show the currently playing song."""
            queue = self.get_music_queue(ctx.guild.id)
            current = queue.current_song()

            if not current:
                await ctx.send("❌ Nothing is currently playing!")
                return

            embed = discord.Embed(
                title="🎵 Now Playing",
                description=f"**{current['title']}**",
                color=discord.Color.blue()
            )

            if current.get('duration'):
                embed.add_field(name="Duration", value=format_duration(current['duration']), inline=True)

            if current.get('webpage_url'):
                embed.add_field(name="Source", value=f"[Link]({current['webpage_url']})", inline=True)

            current_vol = int(BOT_CONFIG.get('default_volume', 0.5) * 100)
            embed.add_field(name="Volume", value=f"{current_vol}%", inline=True)

            if current.get('thumbnail'):
                embed.set_thumbnail(url=current['thumbnail'])

            await ctx.send(embed=embed)

        @self.command(name='help', aliases=['h'])
        async def help_command(ctx):
            """Show help information."""
            embed = discord.Embed(
                title="🎵 Music Bot Commands",
                description="Here are all the available commands:",
                color=discord.Color.green()
            )

            commands_info = [
                ("**Basic Playback**", ""),
                ("!play <song/URL>", "Play music from YouTube or other sources"),
                ("!join", "Join your voice channel"),
                ("!leave", "Leave the voice channel"),
                ("!pause", "Pause the current song"),
                ("!resume", "Resume playback"),
                ("!skip", "Skip the current song"),
                ("!stop", "Stop playback and clear queue"),
                ("!queue", "Show the current music queue"),
                ("!clear", "Clear the music queue"),
                ("!volume <0-100>", "Set volume (0-100%) or check current volume"),
                ("!nowplaying", "Show currently playing song with details"),
                ("", ""),
                ("**Playlist Management**", ""),
                ("!playlist_create <name>", "Create a new playlist"),
                ("!playlist_list", "List all server playlists"),
                ("!playlist_show <name>", "Show songs in a playlist"),
                ("!playlist_play <name>", "Play all songs from a playlist"),
                ("!playlist_add <name> <song>", "Add a song to a playlist"),
                ("!playlist_remove <name> <#>", "Remove song by index from playlist"),
                ("!playlist_delete <name>", "Delete a playlist"),
                ("!playlist_search <query>", "Search playlists by name/description"),
                ("", ""),
                ("**Other Commands**", ""),
                ("!sources", "Show supported music sources"),
                ("!help", "Show this help message")
            ]

            for command, description in commands_info:
                embed.add_field(
                    name=command,
                    value=description,
                    inline=False
                )

            embed.set_footer(text="Made with ❤️ using discord.py")
            await ctx.send(embed=embed)

        @self.command(name='sources', aliases=['platforms'])
        async def sources_command(ctx):
            """Show supported music sources."""
            embed = discord.Embed(
                title="🎵 Supported Music Sources",
                description="If YouTube is blocked, try these alternatives:",
                color=discord.Color.blue()
            )

            sources = [
                ("🎵 YouTube", "Use song names or YouTube URLs\n*Note: May be temporarily blocked*"),
                ("🔊 SoundCloud", "Use SoundCloud URLs or try song names"),
                ("🎶 Bandcamp", "Use Bandcamp URLs"),
                ("📻 Vimeo", "Use Vimeo URLs"),
                ("🎧 Other", "Many other audio platforms supported")
            ]

            for source, description in sources:
                embed.add_field(
                    name=source,
                    value=description,
                    inline=False
                )

            embed.add_field(
                name="💡 Tips",
                value="• Try direct URLs from music platforms\n• Use specific song names with artist\n• Wait and retry if YouTube is blocked",
                inline=False
            )

            await ctx.send(embed=embed)

        # === PLAYLIST COMMANDS ===

        @self.command(name='playlist_create', aliases=['pl_create', 'plcreate'])
        async def playlist_create(ctx, name: str, *, description: str = ""):
            """Create a new playlist."""
            if self.playlist_manager.create_playlist(str(ctx.guild.id), name, str(ctx.author.id), description):
                embed = discord.Embed(
                    title="✅ Playlist Created",
                    description=f"Successfully created playlist: **{name}**",
                    color=discord.Color.green()
                )
                if description:
                    embed.add_field(name="Description", value=description, inline=False)
                embed.set_footer(text=f"Created by {ctx.author.display_name}")
                await ctx.send(embed=embed)
            else:
                await ctx.send(f"❌ Playlist **{name}** already exists!")

        @self.command(name='playlist_delete', aliases=['pl_delete', 'pldelete'])
        async def playlist_delete(ctx, *, name: str):
            """Delete a playlist."""
            if self.playlist_manager.delete_playlist(str(ctx.guild.id), name):
                await ctx.send(f"✅ Deleted playlist: **{name}**")
            else:
                await ctx.send(f"❌ Playlist **{name}** not found!")

        @self.command(name='playlist_add', aliases=['pl_add', 'pladd'])
        async def playlist_add(ctx, playlist_name: str, *, search_query: str):
            """Add a song to a playlist."""
            # Check if playlist exists
            playlist = self.playlist_manager.get_playlist(str(ctx.guild.id), playlist_name)
            if not playlist:
                await ctx.send(f"❌ Playlist **{playlist_name}** not found!")
                return

            # Search for the song
            loading_msg = await ctx.send(f"🔍 Searching for: **{search_query}**...")

            try:
                audio_info = await self.extract_audio_info(search_query)

                if self.playlist_manager.add_song_to_playlist(str(ctx.guild.id), playlist_name, audio_info):
                    embed = discord.Embed(
                        title="✅ Song Added to Playlist",
                        description=f"Added **{audio_info['title']}** to playlist **{playlist_name}**",
                        color=discord.Color.green()
                    )
                    embed.add_field(name="Duration", value=format_duration(audio_info.get('duration')), inline=True)
                    await loading_msg.edit(content="", embed=embed)
                else:
                    await loading_msg.edit(content=f"❌ Failed to add song to playlist!")

            except Exception as e:
                await loading_msg.edit(content=f"❌ Error: {str(e)}")

        @self.command(name='playlist_remove', aliases=['pl_remove', 'plremove'])
        async def playlist_remove(ctx, playlist_name: str, song_index: int):
            """Remove a song from a playlist by index."""
            if self.playlist_manager.remove_song_from_playlist(str(ctx.guild.id), playlist_name, song_index - 1):
                await ctx.send(f"✅ Removed song #{song_index} from playlist **{playlist_name}**")
            else:
                await ctx.send(f"❌ Invalid song index or playlist not found!")

        @self.command(name='playlist_show', aliases=['pl_show', 'plshow'])
        async def playlist_show(ctx, *, name: str):
            """Show songs in a playlist."""
            playlist = self.playlist_manager.get_playlist(str(ctx.guild.id), name)
            if not playlist:
                await ctx.send(f"❌ Playlist **{name}** not found!")
                return

            embed = discord.Embed(
                title=f"🎵 Playlist: {playlist['name']}",
                description=playlist.get('description', 'No description'),
                color=discord.Color.blue()
            )

            songs = playlist.get('songs', [])
            if not songs:
                embed.add_field(name="Songs", value="No songs in this playlist", inline=False)
            else:
                song_list = ""
                for i, song in enumerate(songs[:10], 1):  # Show first 10 songs
                    duration = format_duration(song.get('duration'))
                    song_list += f"{i}. **{song['title']}** ({duration})\n"

                embed.add_field(name=f"Songs (Showing {min(len(songs), 10)} of {len(songs)})", value=song_list, inline=False)

                if len(songs) > 10:
                    embed.add_field(name="Note", value=f"Use `!playlist_play {name}` to play all songs", inline=False)

            # Add metadata
            stats = self.playlist_manager.get_playlist_stats(str(ctx.guild.id), name)
            if stats:
                embed.add_field(name="Total Duration", value=format_duration(stats['total_duration']), inline=True)
                embed.add_field(name="Play Count", value=str(stats['play_count']), inline=True)
                embed.add_field(name="Songs", value=str(stats['song_count']), inline=True)

            await ctx.send(embed=embed)

        @self.command(name='playlist_play', aliases=['pl_play', 'plplay'])
        async def playlist_play(ctx, *, name: str):
            """Play all songs from a playlist."""
            playlist = self.playlist_manager.get_playlist(str(ctx.guild.id), name)
            if not playlist:
                await ctx.send(f"❌ Playlist **{name}** not found!")
                return

            songs = playlist.get('songs', [])
            if not songs:
                await ctx.send(f"❌ Playlist **{name}** is empty!")
                return

            # Join voice channel if not already connected
            voice_client = await self.join_voice_channel(ctx)
            if not voice_client:
                return

            # Add all songs to queue
            queue = self.get_music_queue(ctx.guild.id)
            added_count = 0

            for song in songs:
                queue.add_song(song)
                added_count += 1

            # Increment play count
            self.playlist_manager.increment_play_count(str(ctx.guild.id), name)

            embed = discord.Embed(
                title="✅ Playlist Added to Queue",
                description=f"Added **{added_count}** songs from playlist **{name}** to the queue",
                color=discord.Color.green()
            )

            await ctx.send(embed=embed)

            # Start playing if nothing is currently playing
            if not voice_client.is_playing():
                await self.play_next_song(ctx)

        @self.command(name='playlist_list', aliases=['pl_list', 'playlists'])
        async def playlist_list(ctx):
            """List all playlists in this server."""
            playlists = self.playlist_manager.get_all_playlists(str(ctx.guild.id))

            if not playlists:
                await ctx.send("📋 No playlists found in this server!")
                return

            embed = discord.Embed(
                title="📋 Server Playlists",
                color=discord.Color.blue()
            )

            for name, data in playlists.items():
                song_count = len(data.get('songs', []))
                play_count = data.get('play_count', 0)
                description = data.get('description', 'No description')[:50]
                if len(data.get('description', '')) > 50:
                    description += "..."

                embed.add_field(
                    name=f"🎵 {name}",
                    value=f"**{song_count}** songs • **{play_count}** plays\n{description}",
                    inline=False
                )

            embed.set_footer(text=f"Total: {len(playlists)} playlists")
            await ctx.send(embed=embed)

        @self.command(name='playlist_rename', aliases=['pl_rename', 'plrename'])
        async def playlist_rename(ctx, old_name: str, *, new_name: str):
            """Rename a playlist."""
            if self.playlist_manager.rename_playlist(str(ctx.guild.id), old_name, new_name):
                await ctx.send(f"✅ Renamed playlist **{old_name}** to **{new_name}**")
            else:
                await ctx.send(f"❌ Could not rename playlist. Check if **{old_name}** exists and **{new_name}** is available.")

        @self.command(name='playlist_search', aliases=['pl_search', 'plsearch'])
        async def playlist_search(ctx, *, query: str):
            """Search for playlists by name or description."""
            matching_playlists = self.playlist_manager.search_playlists(str(ctx.guild.id), query)

            if not matching_playlists:
                await ctx.send(f"🔍 No playlists found matching: **{query}**")
                return

            embed = discord.Embed(
                title=f"🔍 Search Results for: {query}",
                color=discord.Color.blue()
            )

            for name in matching_playlists[:10]:  # Show first 10 results
                playlist = self.playlist_manager.get_playlist(str(ctx.guild.id), name)
                if playlist:
                    song_count = len(playlist.get('songs', []))
                    description = playlist.get('description', 'No description')[:50]
                    if len(playlist.get('description', '')) > 50:
                        description += "..."

                    embed.add_field(
                        name=f"🎵 {name}",
                        value=f"**{song_count}** songs\n{description}",
                        inline=False
                    )

            await ctx.send(embed=embed)

    async def play_next_song(self, ctx):
        """Play the next song in the queue."""
        queue = self.get_music_queue(ctx.guild.id)
        voice_client = ctx.guild.voice_client

        if not voice_client:
            return

        if queue.is_empty():
            logger.info(f"Queue empty in {ctx.guild.name}")
            return

        # Get next song
        song_info = queue.get_next_song()
        if not song_info:
            return

        try:
            # Log the URL for debugging
            logger.info(f"Attempting to play URL: {song_info['url']}")

            # Create audio source with multiple fallback options
            audio_source = None

            # Get current volume setting
            current_volume = BOT_CONFIG.get('default_volume', 0.5)

            # Try different FFmpeg configurations with proper volume control
            ffmpeg_configs = [
                # Opus encoding for Discord (preferred) with proper volume
                {
                    'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5 -nostdin -protocol_whitelist file,http,https,tcp,tls,crypto',
                    'options': f'-vn -c:a libopus -b:a 128k -ar 48000 -ac 2 -filter:a "volume={current_volume}"'
                },
                # HLS/m3u8 config for streaming services
                {
                    'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5 -nostdin -protocol_whitelist file,http,https,tcp,tls,crypto',
                    'options': f'-vn -f s16le -ar 48000 -ac 2 -filter:a "volume={current_volume}"'
                },
                # Primary config with proper volume
                {
                    'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5 -nostdin',
                    'options': f'-vn -filter:a "volume={current_volume}"'
                },
                # Fallback config 1
                {
                    'before_options': '-nostdin',
                    'options': '-vn'
                },
                # Fallback config 2
                {
                    'options': '-vn'
                },
                # Basic config
                {}
            ]

            last_error = None
            for i, config in enumerate(ffmpeg_configs):
                try:
                    logger.info(f"Trying FFmpeg config {i+1}/{len(ffmpeg_configs)}: {config}")

                    # Try OpusAudio first (Discord's preferred format)
                    if i == 0:
                        try:
                            audio_source = discord.FFmpegOpusAudio(song_info['url'], **config)
                            logger.info(f"Successfully created Opus audio source with config {i+1}")
                            break
                        except Exception as opus_error:
                            logger.warning(f"Opus encoding failed: {opus_error}, trying PCM")

                    # Fallback to PCM audio
                    audio_source = discord.FFmpegPCMAudio(song_info['url'], **config)
                    logger.info(f"Successfully created PCM audio source with config {i+1}")
                    break
                except Exception as ffmpeg_error:
                    last_error = ffmpeg_error
                    logger.warning(f"FFmpeg config {i+1} failed: {ffmpeg_error}")
                    if i == len(ffmpeg_configs) - 1:
                        raise last_error

            if not audio_source:
                raise Exception("Could not create audio source with any FFmpeg configuration")

            # Check if voice client is ready
            if not voice_client or not voice_client.is_connected():
                raise Exception("Voice client not connected")

            # Play the song
            def after_playing(error):
                if error:
                    logger.error(f"Player error: {error}")
                    asyncio.run_coroutine_threadsafe(
                        ctx.send(f"❌ Playback error: {error}"),
                        self.loop
                    )
                else:
                    logger.info(f"Finished playing: {song_info['title']}")

                # Schedule next song
                future = asyncio.run_coroutine_threadsafe(
                    self.play_next_song(ctx),
                    self.loop
                )
                try:
                    future.result()
                except Exception as e:
                    logger.error(f"Error scheduling next song: {e}")

            try:
                voice_client.play(audio_source, after=afterplaying)
                logger.info(f"Now playing: {song_info['title']} in {ctx.guild.name}")
                await ctx.send(f"🎵 Now playing: **{song_info['title']}**")
            except Exception as play_error:
                logger.error(f"Voice client play error: {play_error}")
                raise play_error

        except Exception as e:
            error_msg = str(e) if str(e) else "Unknown playback error occurred"
            logger.error(f"Error playing song: {error_msg}")
            await ctx.send(f"❌ Error playing song: {error_msg}")
            # Try to play next song
            await self.play_next_song(ctx)