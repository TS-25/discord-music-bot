# 🎵 Playlist Management Guide

The Discord Music Bot now includes a comprehensive playlist system that allows users to create, manage, and play custom playlists in their Discord servers.

## 📋 Quick Start

### Creating Your First Playlist
```
!playlist_create MyPlaylist A collection of my favorite songs
```

### Adding Songs to Playlists
```
!playlist_add MyPlaylist bohemian rhapsody
!playlist_add MyPlaylist https://soundcloud.com/example-song
```

### Playing a Playlist
```
!playlist_play MyPlaylist
```

## 🎛️ Complete Command Reference

### Basic Playlist Operations

| Command | Aliases | Description | Example |
|---------|---------|-------------|---------|
| `!playlist_create <name> [description]` | `!pl_create`, `!plcreate` | Create a new playlist | `!playlist_create Rock "My rock collection"` |
| `!playlist_delete <name>` | `!pl_delete`, `!pldelete` | Delete a playlist | `!playlist_delete Rock` |
| `!playlist_list` | `!pl_list`, `!playlists` | List all server playlists | `!playlist_list` |
| `!playlist_show <name>` | `!pl_show`, `!plshow` | Show songs in a playlist | `!playlist_show Rock` |

### Song Management

| Command | Aliases | Description | Example |
|---------|---------|-------------|---------|
| `!playlist_add <playlist> <song>` | `!pl_add`, `!pladd` | Add song to playlist | `!playlist_add Rock stairway to heaven` |
| `!playlist_remove <playlist> <index>` | `!pl_remove`, `!plremove` | Remove song by index | `!playlist_remove Rock 3` |

### Playback & Search

| Command | Aliases | Description | Example |
|---------|---------|-------------|---------|
| `!playlist_play <name>` | `!pl_play`, `!plplay` | Play entire playlist | `!playlist_play Rock` |
| `!playlist_search <query>` | `!pl_search`, `!plsearch` | Search playlists | `!playlist_search rock` |
| `!playlist_rename <old> <new>` | `!pl_rename`, `!plrename` | Rename a playlist | `!playlist_rename Rock "Classic Rock"` |

## 🎯 Features

### ✅ Persistent Storage
- Playlists are saved automatically to JSON files
- Each Discord server has isolated playlists
- Data persists across bot restarts

### ✅ Multi-Source Support
- Add songs from YouTube, SoundCloud, Bandcamp, and more
- Support for direct URLs and search queries
- Automatic fallback when sources are blocked

### ✅ Rich Information Display
- Beautiful embedded messages with metadata
- Song duration, play counts, and creation dates
- Playlist statistics and total duration

### ✅ Smart Search & Management
- Case-insensitive playlist names
- Search by playlist name or description
- Easy song removal by index number

### ✅ Queue Integration
- Seamlessly integrates with existing music queue
- Play entire playlists with one command
- Maintains playback history and statistics

## 📊 Playlist Statistics

Each playlist tracks:
- **Song Count**: Total number of songs
- **Total Duration**: Combined length of all songs
- **Play Count**: How many times the playlist has been played
- **Creation Date**: When the playlist was created
- **Last Modified**: When songs were last added/removed

## 🎵 Usage Examples

### Creating Different Types of Playlists

```bash
# Create a simple playlist
!playlist_create Chill

# Create with description
!playlist_create "Study Music" "Perfect for focusing and productivity"

# Create themed playlists
!playlist_create "90s Hits" "The best songs from the 90s decade"
```

### Building Your Collection

```bash
# Add individual songs
!playlist_add "90s Hits" "Smells Like Teen Spirit"
!playlist_add "90s Hits" "Wonderwall"
!playlist_add "90s Hits" "Black"

# Add from different platforms
!playlist_add Chill https://soundcloud.com/artist/relaxing-song
!playlist_add Chill "lofi hip hop beats"
```

### Managing Playlists

```bash
# View all your playlists
!playlist_list

# Check what's in a playlist
!playlist_show "90s Hits"

# Remove unwanted songs (by number from !playlist_show)
!playlist_remove "90s Hits" 2

# Rename for better organization
!playlist_rename "90s Hits" "90s Rock Classics"
```

### Playing Music

```bash
# Play entire playlist
!playlist_play "90s Rock Classics"

# Play will add all songs to queue and start immediately
# Use normal queue commands (!skip, !pause, etc.) during playback
```

## 🔍 Tips & Best Practices

### Organization
- Use descriptive names for easy identification
- Add descriptions to remember playlist purposes
- Create themed playlists (genre, mood, activity)

### Song Management
- Use `!playlist_show` to see song indices before removing
- Try different search terms if songs aren't found
- Use direct URLs for rare or specific tracks

### Server Usage
- Each Discord server has its own playlist collection
- Playlists are shared among all server members
- Anyone can create and manage playlists (unless restricted)

### Performance
- Large playlists (100+ songs) may take a moment to load into queue
- Consider breaking very large collections into smaller themed playlists
- Use search function to quickly find specific playlists

## 🎨 Visual Examples

When you create a playlist, you'll see:
```
✅ Playlist Created
Successfully created playlist: My Playlist
Description: Collection of my favorite songs
Created by YourUsername
```

When viewing a playlist:
```
🎵 Playlist: My Playlist
Description: Collection of my favorite songs

Songs (Showing 5 of 8):
1. Bohemian Rhapsody (6:07)
2. Stairway to Heaven (8:02)
3. Hotel California (6:30)
4. Sweet Child O' Mine (5:56)
5. November Rain (9:18)

Total Duration: 47:23 • Play Count: 5 • Songs: 8
```

## 🚀 Advanced Usage

### Batch Operations
You can quickly build playlists by adding multiple songs in sequence:
```bash
!playlist_add Rock "Led Zeppelin - Stairway to Heaven"
!playlist_add Rock "Queen - Bohemian Rhapsody"
!playlist_add Rock "AC/DC - Thunderstruck"
```

### Cross-Platform Collections
Mix and match from different music sources:
```bash
!playlist_add Mixed https://www.youtube.com/watch?v=example
!playlist_add Mixed https://soundcloud.com/artist/song
!playlist_add Mixed "spotify song name"  # Will find alternatives
```

Enjoy your enhanced music experience with playlist management! 🎵